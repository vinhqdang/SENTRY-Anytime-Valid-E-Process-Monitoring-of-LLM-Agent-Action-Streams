SENTRY-Fuse -- submission package for Computers & Security (Elsevier)

MAIN MANUSCRIPT (LaTeX source bundle)
  sentry_cose.tex        main manuscript (elsarticle, preprint, 12pt), 6 sections
  sentry_cose.bbl        pre-compiled bibliography
  references_cose.bib    BibTeX source (34 entries)
  figures/*.pdf          all figures referenced by the manuscript
  elsarticle.cls         document class
  elsarticle-harv.bst    bibliography style

SEPARATE UPLOADS (do not include inside the manuscript bundle)
  cose_highlights.pdf / .txt   Highlights: 5 bullets, each <= 85 characters
  cose_cover_letter.pdf        Cover letter to the Editors
  cose_declarations.pdf        Competing interests, funding, CRediT, data
                               availability, ethics, generative-AI use

COMPILE
  pdflatex sentry_cose && bibtex sentry_cose && pdflatex sentry_cose && pdflatex sentry_cose
